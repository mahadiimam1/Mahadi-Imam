 <?php
 
 class Super_admin {

    private $db_connect;

//===================================================database connection=======================================
    public function __construct() {
        // just connect database 
        $host = 'localhost';
        $user = 'root';
        $password = '';
        $database = 'khanstore';
        $this->db_connect = mysqli_connect($host, $user, $password, $database);
        if (!$this->db_connect) {
            die("Database Not Connect Successfully !!" . mysqli_error($this->db_connect));
        }
    }
	
	
 public  function Add($received_id,$totalAmount,$ProductName,$Quantity,$price) {
        $query = "insert into orderproduct(id,totalAmount,ProductName,Quantity,price) values('$received_id','$totalAmount','$ProductName','$Quantity','$price')";

        if (mysqli_query($this->db_connect, $query)) {
            $query = "DELETE FROM `cart` ";
               if (mysqli_query($this->db_connect, $query)) {
               $massage = "Congratulation Ordered Succesfully  !!";
			   }
            return $massage;
        } else {
            die("Query Problem" . mysqli_error($this->db_connect));
        }
    }
	
	
	  public function Select($received_id) {
        $query = "select * from orderproduct where id='$received_id'";
        if (mysqli_query($this->db_connect, $query)) {
            $query_data = mysqli_query($this->db_connect, $query);
            return $query_data;
        } else {
            die("Query Problem" . mysqli_error($this->db_connect));
        }
    }
	
	  public function Select1($id ) {
        $query = "select first_name from user_info where user_id='$id'";
        if (mysqli_query($this->db_connect, $query)) {
            $query_data = mysqli_query($this->db_connect, $query);
            return $query_data;
        } else {
            die("Query Problem" . mysqli_error($this->db_connect));
        }
    }
	
	
	  public  function saveInfo($data) {
        $query = "insert into refundTable(id,name,mobile,address,productName) values('$data[id]','$data[name]','$data[mobile]','$data[address]','$data[productName]')";

        if (mysqli_query($this->db_connect, $query)) {
			  $massage1 = "your order cancel ";
			  session_start();
			  $_SESSION['massage']   =  $massage1 ;
         
          header('location:profile.php');
        } else {
            die("Query Problem" . mysqli_error($this->db_connect));
        }
    }
	
	

               
 }
 


	?>