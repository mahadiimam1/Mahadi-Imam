<?php 



require 'super_admin.php';
$obj_super_admin = new Super_admin();


$received_id = $_GET['id'];
$totalAmount= $_GET['totalAmount'];
$ProductName = $_GET['ProductName'];
$Quantity = $_GET['Quantity'];
$price = $_GET['price'];



  $received = $obj_super_admin->Add($received_id,$totalAmount,$ProductName,$Quantity,$price); //parametter pass


$allInfo = $obj_super_admin->Select($received_id);
    
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="profile.php">Book Store</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="profile.php">Home</a></li>

    </ul>
  </div>
</nav>
  
<div class="container">

<h2 style="color:green; text-align:center;"> <?php if (isset($received)) echo $received; ?></h2>
</div>

<div class="container">
  <h2>My Order List</h2>
           
  <table class="table table-striped">
    <thead>
      <tr>
	   <th>Product Name</th>
        <th>total Amount</th>
       
        <th>Quantity</th>
		<th>price</th>
      </tr>
    </thead>
    <tbody>
             <?php while ($all_result = mysqli_fetch_assoc($allInfo)) { ?>
                        <tr>     
           <td class="center"><?php echo $all_result['ProductName']; ?></td>						
                            <td class="center"><?php echo $all_result['totalAmount']; ?></td>
                 
                            <td class="center"><?php echo $all_result['Quantity']; ?></td>
                          
			               <td class="center"><?php echo $all_result['price']; ?></td>
			 <?php }?>
    </tbody>
  </table>
  
<form>
<input type="button" value="Refund" onclick="window.location.href='confarmation.php?id=<?php echo $received_id ;?>'" />
</form>

<br>
</div>

</body>
</html>
