<?php
require 'super_admin.php';
$obj_super_admin = new Super_admin();
$id = $_GET['id'];
$allInfo2 = $obj_super_admin->Select($id);

$allInfo1 = $obj_super_admin->Select1($id);
$info=mysqli_fetch_assoc($allInfo1);


if (isset($_POST['btn'])) {
 $obj_super_admin->saveInfo($_POST);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="profile.php">Book Store</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="profile.php">Home</a></li>

    </ul>
  </div>
</nav>
  
<div class="container">


</div>

<div class="container">
  <h2>Refund Product</h2>
  
  <form action="" method="post">
            
  <table class="table table-striped">
    
      <tr>
	   <td> Name</td>
	   <td> <input type='text' name="name"  value="<?php echo $info['first_name']; ?>" readonly/></td>
	   	   <td> <input type='hidden' name="id"  value="<?php echo $id; ?>" readonly/></td>
  </tr>
        <tr>
	   <td>Mobile No</td>
	   <td> <input type='text' name="mobile" /></td>
  </tr>
        <tr>
	   <td>Address</td>
	   <td> <input type='text' name="address" /></td>
  </tr>
        <tr>
	   <td>Refund Ordered Book</td>
	   <td><select name="productName">
	     <?php while ($all_result = mysqli_fetch_assoc($allInfo2)) { ?>
  <option value="<?php echo $all_result['ProductName']; ?>"><?php echo $all_result['ProductName']; ?></option>
		<?php }?>

</select></td>

<tr>
	   <td> </td>
	   <td> <input type='submit' name="btn"  value="Submit Now" /></td>
  </tr>

  </tr>
  </table>
  


<br>
</div>

</body>
</html>
